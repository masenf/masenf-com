Hello,

This collection of presets for milkdrop 2 beta represents countless hours of time intoxicated on various substances, amphetamines being my favorite. I was creating (or remixing, whatever you prefer) these files up until the time I went into a rehabilitation treatment center for chemical dependency, namely for prescription amphetamines, crystal methamphetamines, marijuana, alcohol, lsd, ecstasy, dxm and many others.
I didn't credit anyone with the code they created. I'm sorry! I hope you aren't mad!
Life today is far different. For now I just don't get high, every day, no matter what. Even though I really want to, sometimes. I hope I included everything you need to enjoy my presets.

I dedicate this collection to all the addicts out there still suffering.


There is help, there is hope, you just have to reach out.


Sincerely,
Desperately,
Fondly,
Sadly,

LuxXx aka Tristan S.
trystynsly@gmail.com